document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('.navbar nav ul li a');
    const sections = document.querySelectorAll('main section');
    const timeFilterButtons = document.querySelectorAll('.time-filter-btn');
    const challengeFilterButtons = document.querySelectorAll('.challenge-filter-btn');
    const categoryFilterButtons = document.querySelectorAll('.tips-section .filter-btn[data-category]');
    const impactFilterButtons = document.querySelectorAll('.tips-section .filter-btn[data-impact]');
    const recommendationCards = document.querySelectorAll('.recommendation-card');
    const noRecommendationsMessage = document.getElementById('no-recommendations');
    const challengeCards = document.querySelectorAll('.challenge-grid .challenge-card');
    const totalCarbonEmissions = document.getElementById('total-carbon-emissions');

    // Chart.js instances
    let carbonBreakdownChart;
    let monthlyCarbonTrendChart;

    // --- Navigation Logic ---
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();

            navLinks.forEach(item => item.classList.remove('active'));
            link.classList.add('active');

            sections.forEach(section => section.classList.add('hidden'));

            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.remove('hidden');
                // Initialize charts when dashboard is shown
                if (targetId === 'dashboard') {
                    renderCarbonBreakdownChart();
                    renderMonthlyCarbonTrendChart();
                    updateDashboardData('month'); // Default to month view
                }
            }
        });
    });

    // Set initial active section to Home
    document.getElementById('home').classList.remove('hidden');
    document.querySelector('.navbar nav ul li a[href="#home"]').classList.add('active');

    // --- Dashboard Logic ---
    const dashboardData = {
        day: {
            total: 12.4,
            breakdown: {
                transportation: { percentage: 39, kgco2: 4.8 },
                homeEnergy: { percentage: 25, kgco2: 3.1 },
                foodDiet: { percentage: 21, kgco2: 2.6 },
                shopping: { percentage: 15, kgco2: 1.9 }
            },
            change: "12% lower than previous day"
        },
        week: {
            total: 87.3,
            breakdown: {
                transportation: { percentage: 39, kgco2: 34.0 },
                homeEnergy: { percentage: 25, kgco2: 21.8 },
                foodDiet: { percentage: 21, kgco2: 18.3 },
                shopping: { percentage: 15, kgco2: 13.1 }
            },
            change: "12% lower than previous week"
        },
        month: {
            total: 371,
            breakdown: {
                transportation: { percentage: 39, kgco2: 144.69 },
                homeEnergy: { percentage: 25, kgco2: 92.75 },
                foodDiet: { percentage: 21, kgco2: 77.91 },
                shopping: { percentage: 15, kgco2: 55.65 }
            },
            change: "12% lower than previous month"
        },
        year: {
            total: 4532.8,
            breakdown: {
                transportation: { percentage: 39, kgco2: 1767.79 },
                homeEnergy: { percentage: 25, kgco2: 1133.2 },
                foodDiet: { percentage: 21, kgco2: 951.89 },
                shopping: { percentage: 15, kgco2: 679.92 }
            },
            change: "12% lower than previous year"
        }
    };

    function updateDashboardData(period) {
        const data = dashboardData[period];
        if (data) {
            totalCarbonEmissions.textContent = data.total;
            document.querySelector('.percentage-change').innerHTML = `<i class="fas fa-caret-down"></i> ${data.change}`;

            document.getElementById('transportation-percentage').textContent = `${data.breakdown.transportation.percentage}%`;
            document.getElementById('home-energy-percentage').textContent = `${data.breakdown.homeEnergy.percentage}%`;
            document.getElementById('food-diet-percentage').textContent = `${data.breakdown.foodDiet.percentage}%`;
            document.getElementById('shopping-percentage').textContent = `${data.breakdown.shopping.percentage}%`;

            if (carbonBreakdownChart) {
                carbonBreakdownChart.data.datasets[0].data = [
                    data.breakdown.transportation.percentage,
                    data.breakdown.homeEnergy.percentage,
                    data.breakdown.foodDiet.percentage,
                    data.breakdown.shopping.percentage
                ];
                carbonBreakdownChart.update();
            }

             // Update hover values for breakdown chart
             carbonBreakdownChart.options.plugins.tooltip.callbacks.label = function(context) {
                let label = context.label || '';
                if (label) {
                    label += ': ';
                }
                const value = context.raw;
                const category = context.label.split(': ')[0]; // Extract category name from label
                let kgco2Value = 0;
                 if (category.includes('Transportation')) kgco2Value = data.breakdown.transportation.kgco2;
                else if (category.includes('Home Energy')) kgco2Value = data.breakdown.homeEnergy.kgco2;
                else if (category.includes('Food & Diet')) kgco2Value = data.breakdown.foodDiet.kgco2;
                else if (category.includes('Shopping')) kgco2Value = data.breakdown.shopping.kgco2;

                return `${label}${value}% (${kgco2Value.toFixed(2)} kg CO₂)`;
            };
            carbonBreakdownChart.update();
        }
    }

    timeFilterButtons.forEach(button => {
        button.addEventListener('click', () => {
            timeFilterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            const period = button.dataset.time;
            updateDashboardData(period);
        });
    });

    function renderCarbonBreakdownChart() {
        const ctx = document.getElementById('carbonBreakdownChart').getContext('2d');
        if (carbonBreakdownChart) {
            carbonBreakdownChart.destroy();
        }
        carbonBreakdownChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Transportation', 'Home Energy', 'Food & Diet', 'Shopping'],
                datasets: [{
                    data: [39, 25, 21, 15], // Default Month data
                    backgroundColor: ['#4CAF50', '#FFC107', '#00BCD4', '#9C27B0'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false // We use custom legend HTML
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                const value = context.raw;
                                const data = dashboardData[document.querySelector('.time-filter-btn.active').dataset.time];
                                const category = context.label;
                                let kgco2Value = 0;
                                if (category === 'Transportation') kgco2Value = data.breakdown.transportation.kgco2;
                                else if (category === 'Home Energy') kgco2Value = data.breakdown.homeEnergy.kgco2;
                                else if (category === 'Food & Diet') kgco2Value = data.breakdown.foodDiet.kgco2;
                                else if (category === 'Shopping') kgco2Value = data.breakdown.shopping.kgco2;

                                return `${label}${value}% (${kgco2Value.toFixed(2)} kg CO₂)`;
                            }
                        }
                    }
                }
            }
        });
    }

    function renderMonthlyCarbonTrendChart() {
        const ctx = document.getElementById('monthlyCarbonTrend').getContext('2d');
        if (monthlyCarbonTrendChart) {
            monthlyCarbonTrendChart.destroy();
        }
        monthlyCarbonTrendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Carbon Emissions (kg CO₂)',
                    data: [500, 480, 410, 390, 370, 320, 300, 290, 280, 260, 250, 240],
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.2)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                return `${label}${context.raw} kg CO₂`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: false,
                            text: 'Month'
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        title: {
                            display: false,
                            text: 'Carbon (kg CO₂)'
                        },
                        beginAtZero: true,
                        max: 600
                    }
                }
            }
        });
    }

    // --- Tips/Recommendations Logic ---
    let currentCategoryFilter = 'all';
    let currentImpactFilter = 'all';

    function filterRecommendations() {
        let anyVisible = false;
        recommendationCards.forEach(card => {
            const cardCategory = card.dataset.category;
            const cardImpact = card.dataset.impact;

            const categoryMatch = (currentCategoryFilter === 'all' || cardCategory === currentCategoryFilter);
            const impactMatch = (currentImpactFilter === 'all' || cardImpact === currentImpactFilter);

            if (categoryMatch && impactMatch) {
                card.classList.remove('hidden');
                anyVisible = true;
            } else {
                card.classList.add('hidden');
            }
        });

        if (anyVisible) {
            noRecommendationsMessage.classList.add('hidden');
        } else {
            noRecommendationsMessage.classList.remove('hidden');
        }
    }

    categoryFilterButtons.forEach(button => {
        button.addEventListener('click', () => {
            categoryFilterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            currentCategoryFilter = button.dataset.category;
            filterRecommendations();
        });
    });

    impactFilterButtons.forEach(button => {
        button.addEventListener('click', () => {
            impactFilterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            currentImpactFilter = button.dataset.impact;
            filterRecommendations();
        });
    });

    // Initial filter for tips section
    filterRecommendations();


    // --- Challenges Logic ---
    challengeFilterButtons.forEach(button => {
        button.addEventListener('click', () => {
            challengeFilterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filterType = button.dataset.challengeType;

            challengeCards.forEach(card => {
                const cardType = card.dataset.challengeType;
                if (filterType === 'all' || filterType === cardType) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });

    // Calendar Icon (for demonstration, a full date picker library would be needed)
    document.querySelectorAll('.calendar-icon').forEach(icon => {
        icon.addEventListener('click', () => {
            alert('Date picker functionality would be integrated here.');
            // In a real application, you would initialize a date picker library here.
        });
    });

    // Log Activity Button (basic alert)
    document.querySelectorAll('.record-activity-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            alert('Activity recorded! (This is a placeholder action)');
            // In a real application, you would collect form data and send it to a backend.
        });
    });
});